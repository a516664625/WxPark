//获取应用实例
const app = getApp()
const serviceUrl = app.globalData.serviceUrl
Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    tokens: wx.getStorageSync("tokens")
  },

  onLoad: function () {
    var that = this;
    var tokens = wx.getStorageSync("park_token")
    // 查看是否授权
    if (tokens) {
      wx.switchTab({
        url: '../parking/parking'
      })
    }
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    }
    else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
    
  },
  logg:function(ee){
    wx.navigateTo({
      url: '../login/login',
    })
  },
  
  getUserInfo: function (e){
    var info = e.detail.userInfo
    var that_g = this
    wx.login({
      success:res=>{
        wx.request({
          url: serviceUrl+'wx/getid',
          method: 'POST',
          header: {
            "content-type": "application/json"
          },
          data: {
            wxcode: res.code
          },
          success:res=>{
            wx.request({
              url: serviceUrl+'wx/Wxlogin',
              header: {
                "content-type": "application/json"
              },
              method: 'post',
              data: {
                openid: res.data.openid,
                session_key: res.data.session_key,
                nickname: info.nickName,
                gender: info.gender,
                city: info.city,
                country: info.country,
                province: info.province,
                avatUrl: info.avatarUrl
              },
              success(res){
                wx.setStorageSync('park_token', res.data.token)
                wx.setStorageSync('park_id', res.data.id)
                wx.setStorageSync('openid', res.data.openid)
                app.globalData.userInfo = e.detail.userInfo
                wx.switchTab({
                  url: '../parking/parking'
                })
                that_g.setData({
                  userInfo: info,
                  hasUserInfo: true
                })

              },
              fail(res) {
                console.log(res)
                wx.showToast({
                  title: '有错误',
                  icon: 'fail',
                  duration: 2000
                })
              }

            })
          }

        })
      }
    })


  },

})

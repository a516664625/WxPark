const app = getApp()
const serviceUrl = app.globalData.serviceUrl

Page({
  data: { //此处定义本页面中的全局变量
    result: '',
    email: '',
    username: '',
    passwd: '',
    passwd2: '',
    user: '',
    wxcode: ''
  },
  inputEmail: function(e) {
    this.data.email = e.detail.value;
  },
  usernameInput: function(e) {
    this.data.username = e.detail.value;
  },
  passwordInput: function(e) {
    this.data.password = e.detail.value;
  },
  twoPassword: function(e) {
    this.data.twopassword = e.detail.value;
  },


  reg: function(e) { //与服务器进行交互
    wx.request({
      url: serviceUrl + 'wx/register', //获取服务器地址，此处为本地地址
      header: {
        "content-type": "application/json" //使用POST方法要带上这个header
      },
      method: "POST",
      data: { //向服务器发送的信息
        email: this.data.email,
        username: this.data.username,
        passwd: this.data.password,
        passwd2: this.data.twopassword
      },
      success: function(res) {
        if (res.data.code == 200) {
          console.log(res, '->regi')
          wx.navigateTo({
            url: '../login/login',
          })
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'fail',
            duration: 2000,
            mask: true
          })

        }

      }
    })
  }
})
var app = getApp()
const serviceUrl = app.globalData.serviceUrl
console.log(serviceUrl)
// parking.js
var util = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    parkingNum: '',
    parkingSite: '智慧停车场',
    freDate: util.formatTime(new Date())
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var self = this;
      wx.request({
        url: serviceUrl+'LPRC/emptyNum',
        method: 'get',
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          console.log(res.data);
          var response = res.data.emptyNum;
          self.setData({
            parkingNum: response,
           
          })
        },
        fail: function (err) {
          console.log(err)
        }
      })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var self = this;
    wx.showNavigationBarLoading()
      wx.request({
        url: serviceUrl+'LPRC/emptyNum',
        method: 'get',
        data: {},
        header: {
          'content-type': 'json'
        },
        success: function (res) {
          wx.stopPullDownRefresh() //停止下拉刷新
          wx.hideNavigationBarLoading() //完成停止加载
          var response = res.data.data;
          self.setData({
            parkingNum: response,
            freDate: util.formatTime(new Date())
          })

        },
        fail: function (err) {
          console.log(err)
        }
      })
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
})
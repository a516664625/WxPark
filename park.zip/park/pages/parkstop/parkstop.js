// pages/detail/detail.js
var app = getApp()
const serviceUrl = app.globalData.serviceUrl
Page({
  data: {
    status: "",
    autoplay: true,
    interval: 2000,
    duration: 500,
    img: ["../../images/stop.png", "../../images/logo.jpg"],
    grids: [{
        name: "停车缴费",
        img: "../../images/stopcar.png",
        url: "../pay/pay"
      },
      {
        name: "停车记录",
        img: "../../images/history.png",
        url: "../mycenter/record/record"
      },
      {
        name: "车牌管理",
        img: "../../images/cp.png",
        url: "../mycenter/mycar/mycar"
      }
    ]
  },
  onLoad: function(options) {
    var self = this;
    wx.request({
      url: serviceUrl+'LPRC/status',
      header: {
        "content-type": "application/json"
      },
      method: 'post',
      data: {
        id: wx.getStorageSync('park_id'),

      },
      success: function(res) {
        console.log(res.data)
        if (res.data.code == 200) {
          var response = res.data.message
          self.setData({
            status: response


          })
        }
      },
      fail: function (err) {
        console.log(err)
      }

    })

  },
  onReady: function() {
    // 页面渲染完成
  },
  onShow: function() {
    // 页面显示
  },
  onHide: function() {
    // 页面隐藏
  },
  onUnload: function() {
    // 页面关闭
  },
  onPullDownRefresh: function() {
    var self = this;
    wx.showNavigationBarLoading()
    wx.request({
      url: serviceUrl+'LPRC/status',
      method: 'post',
      data: {
        id: wx.getStorageSync('park_id'),
      },
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.code == 200) {
          var response = res.data.message
          self.setData({
            status: response


          })
        }
      },
      fail: function(err) {
        console.log(err)
      }
    })

  },


})
var app = getApp();
const serviceUrl = app.globalData.serviceUrl
Page({
  data: {
    
   
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数

  },
  onReady: function () {
    // 页面渲染完成

  },
  onShow: function () {
    // 页面显示

  },
  onHide: function () {
    // 页面隐藏

  },
  onUnload: function () {
    // 页面关闭

  },
  
  log: function (e) {
    wx.showNavigationBarLoading() //顶部显示加载动画
    let email = e.detail.value.email;
    let user_id = wx.getStorageSync('park_id');
    // console.log( username,password )
    wx.request({
      url: serviceUrl+'wx/bindemail',
      method:'post',
      header: {
        'content-type': 'application/json'
      },
      data: {
        'email': email,
        
        'user_id': user_id
      },
      success: function (res) {
        console.log(res)
        if (res.data.code == 200) {  //存储登录状态
          wx.showToast({
            title: '绑定成功',
          })
        } else {
          wx.showModal({
            title: '失败',
            showCancel: false,
            content: res.data.message,
            success: function (res) {
            }
          })
        }
      },
      fail: function () {
        console.log("失败")
      }
    })
  }
})
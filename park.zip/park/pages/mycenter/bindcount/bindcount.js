// pages/mycenter/bindcount/bindcount.js
var app = getApp()
const serviceUrl = app.globalData.serviceUrl
Page({
  /**
   * 页面的初始数据
   */
  data: { //此处定义本页面中的全局变量
    result: '',
    username: '',
    passwd: '',
    wxcode: '',
    openid: '',
    session_key: '',
    jwt_token: '',
    user_id: ''

  },
  inputName: function (e) { // 用于获取输入的账号
    this.setData({
      username: e.detail.value //将获取到的账号赋值给username变量
    })
  },
  inputPwd: function (e) { // 用于获取输入的密码
    this.setData({
      passwd: e.detail.value //将获取到的账号赋值给passwd变量
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  log:function(e){
    wx.request({
      url: serviceUrl+'wx/bindcount',
      header:{
        "content-type": "application/json"
      },
      method: "POST",
      data: { //向服务器发送的信息
        username: this.data.username,
        passwd: this.data.passwd,
        id:wx.getStorageSync('park_id')
      },
      success: function (res) {

        console.log(res.data.code)
        if (res.data.code == 200) {
          wx.showToast({
            title: '绑定成功',
            icon: 'succes',
            duration: 2000,
            mask: true
          }),
            wx.switchTab({

              url: '../mycenter/mycenter',
            })
        } else {
          wx.showToast({
            title: '绑定失败,账号已存在',
            icon: 'fail',
            duration: 2000,
            mask: true
          })

        }

      }

    })

  },
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
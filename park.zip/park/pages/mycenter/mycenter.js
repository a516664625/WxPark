//mine.js
//获取应用实例

var app = getApp()
const serviceUrl = app.globalData.serviceUrl
Page({
  data: {
    userInfo: {},
    ishow:true
  },

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  bind:function(){
    wx.navigateTo({
      url: 'bindcount/bindcount',
    })
    
  },
  onPullDownRefresh:function(){
    var that = this;
    var openid = wx.getStorageSync("openid")
    // 查看是否授权
    if (openid) {
      that.setData({
        ishow: false

      })
    }

  },
  onLoad: function () {
    var that = this;
    var openid = wx.getStorageSync("openid")
    // 查看是否授权
    if (openid) {
      that.setData({
        ishow:false

      })
    }
  },
  wallet: function () {
    wx.navigateTo({
      url: 'wallet/wallet',
    })


  },
  mycar: function() {
    wx.navigateTo({
      url: 'mycar/mycar',
    })
  

  },
  mycarTap: function() {
    wx.navigateTo({
      url: '../carnumber/carnumber',
    })
  },
  getService: function() {
    wx.navigateTo({
      url: 'kefu/kefu',
    })
    
  },
  myAcode: function() {
    
    wx.navigateTo({
      url: 'advice/advice',
    })
    
  },
  // getRecOrders: function() {
    
  //   wx.navigateTo({
  //     url: 'about/about',
  //   })
    
  // },
  getMyIncome: function() {
    
    wx.navigateTo({
      url: 'record/record',
    })
    
   
  },
  bd:function(){
    
    wx.navigateTo({
      url: 'bind_email/bind_email',
    })
  


  },
  getUserInfo: function (e) {
    var info = e.detail.userInfo
    var that_g = this
    wx.login({
      success: res => {
        wx.request({
          url: serviceUrl + 'wx/getid',
          method: 'POST',
          header: {
            "content-type": "application/json"
          },
          data: {
            wxcode: res.code
          },
          success: res => {
            wx.request({
              url: serviceUrl + 'wx/bindwx',
              header: {
                "content-type": "application/json"
              },
              method: 'post',
              data: {
                openid: res.data.openid,
                session_key: res.data.session_key,
                nickname: info.nickName,
                gender: info.gender,
                city: info.city,
                country: info.country,
                province: info.province,
                avatUrl: info.avatarUrl,
                id:wx.getStorageSync('park_id')
              },
              success(res) {
                if (res.data.code==200){
                  wx.setStorageSync('openid', res.data.openid)
                  app.globalData.userInfo = e.detail.userInfo
                  wx.showModal({
                    title: '成功',
                    content: '微信绑定成功',
                  })
                }else{
                  wx.showModal({
                    title: '失败',
                    content: res.data.message,
                  })

                }


              },
              fail(res) {
                console.log(res)
                wx.showToast({
                  title: '有错误',
                  icon: 'fail',
                  duration: 2000
                })
              }

            })
          }

        })
      }
    })


  }

})
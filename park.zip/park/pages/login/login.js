var app = getApp()
const serviceUrl = app.globalData.serviceUrl
Page({
  data: { //此处定义本页面中的全局变量
    result: '',
    username: '',
    passwd: '',
    wxcode: '',
    openid: '',
    session_key: '',
    jwt_token: '',
    user_id: ''

  },
  inputName: function(e) { // 用于获取输入的账号
    this.setData({
      username: e.detail.value //将获取到的账号赋值给username变量
    })
  },
  inputPwd: function(e) { // 用于获取输入的密码
    this.setData({
      passwd: e.detail.value //将获取到的账号赋值给passwd变量
    })
  },


  log: function(e) { //与服务器进行交互
    wx.request({
      url: serviceUrl + 'dtoken/tokens', //获取服务器地址，此处为本地地址
      header: {
        "content-type": "application/json" //使用POST方法要带上这个header
      },
      method: "POST",
      data: { //向服务器发送的信息
        username: this.data.username,
        passwd: this.data.passwd
      },
      success: function(res) {

        console.log(res.data.code)
        if (res.data.code == 200) {
          wx.setStorageSync('park_token', res.data.token)
          wx.setStorageSync('park_id', res.data.id)
          wx.showToast({
              title: res.data.message,
              icon: 'succes',
              duration: 2000,
              mask: true
            }),
            wx.switchTab({

              url: '../parking/parking',
            })
        } else {
          wx.showToast({
            title: res.data.message,
            icon: 'fail',
            duration: 2000,
            mask: true
          })

        }

      }
    })
  },
  bindViewTap: function(e) {
    wx.navigateTo({
      url: '../register/register'
    })
  }

})